import unittest
from simpycity.core import Function, Query
from simpycity.model import SimpleModel
from simpycity import config
import psycopg2
from optparse import OptionParser
import sys

class handleTests(unittest.TestCase):
    
    pass