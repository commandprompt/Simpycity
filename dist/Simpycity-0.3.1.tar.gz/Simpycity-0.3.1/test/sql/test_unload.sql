BEGIN;
DROP TABLE test_table CASCADE;

DROP FUNCTION update_row(int, text);

COMMIT;