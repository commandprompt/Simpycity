port=5432
host="localhost"
database=None
user=None
password=None
debug=False